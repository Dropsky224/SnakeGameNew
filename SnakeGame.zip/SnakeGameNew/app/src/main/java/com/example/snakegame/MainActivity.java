package com.example.snakegame;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements SurfaceHolder.Callback {

    private final List<SnakePoints> snakePointsList = new ArrayList<>();
    private SurfaceView surfaceView;
    private View controlsLayout;
    private SurfaceHolder surfaceHolder;
    private String movingPosition = "right";
    private int score = 0;
    private static final int POINT_SIZE = 28;
    private static final int DEFAULT_TALE_POINTS = 3;
    private static final int SNAKE_MOVING_SPEED = 200;
    private int positionX, positionY;
    private Paint snakePaint;
    private Paint foodPaint;
    private Paint scorePaint;
    private Paint gridPaint;
    private boolean isGameRunning = false;
    private Thread gameThread;
    private int playableHeight = 0;
    private boolean gameOver = false;
    private int snakeColor;
    private int foodColor;
    private int backgroundColor;
    private int gridColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Установка полноэкранного режима
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        // Инициализация цветов
        snakeColor = ContextCompat.getColor(this, R.color.snake_green);
        foodColor = ContextCompat.getColor(this, R.color.food_red);
        backgroundColor = ContextCompat.getColor(this, R.color.background_dark);
        gridColor = ContextCompat.getColor(this, R.color.grid_lines);

        // Инициализация элементов
        surfaceView = findViewById(R.id.surfaceView);
        controlsLayout = findViewById(R.id.controlsLayout);
        final AppCompatImageButton topBtn = findViewById(R.id.topBtn);
        final AppCompatImageButton leftBtn = findViewById(R.id.leftBtn);
        final AppCompatImageButton rightBtn = findViewById(R.id.rightBtn);
        final AppCompatImageButton bottomBtn = findViewById(R.id.bottomBtn);

        // Настройка кистей
        snakePaint = new Paint();
        snakePaint.setColor(snakeColor);
        snakePaint.setStyle(Paint.Style.FILL);
        snakePaint.setAntiAlias(true);

        foodPaint = new Paint();
        foodPaint.setColor(foodColor);
        foodPaint.setStyle(Paint.Style.FILL);
        foodPaint.setAntiAlias(true);

        gridPaint = new Paint();
        gridPaint.setColor(gridColor);
        gridPaint.setStrokeWidth(1);

        scorePaint = new Paint();
        scorePaint.setColor(Color.WHITE);
        scorePaint.setTextSize(60);
        scorePaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        scorePaint.setAntiAlias(true);
        scorePaint.setShadowLayer(5, 3, 3, Color.BLACK);

        surfaceView.getHolder().addCallback(this);

        // Обработчики кнопок
        topBtn.setOnClickListener(v -> {
            if(!movingPosition.equals("bottom")) movingPosition = "top";
        });

        leftBtn.setOnClickListener(v -> {
            if(!movingPosition.equals("right")) movingPosition = "left";
        });

        rightBtn.setOnClickListener(v -> {
            if(!movingPosition.equals("left")) movingPosition = "right";
        });

        bottomBtn.setOnClickListener(v -> {
            if(!movingPosition.equals("top")) movingPosition = "bottom";
        });
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        this.surfaceHolder = holder;
        surfaceView.post(() -> {
            playableHeight = surfaceView.getHeight() - controlsLayout.getHeight();
            init();
        });
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        surfaceView.post(() -> {
            playableHeight = surfaceView.getHeight() - controlsLayout.getHeight();
        });
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        stopGame();
    }

    private void init() {
        stopGame();

        // Сброс игры
        snakePointsList.clear();
        score = 0;
        movingPosition = "right";
        gameOver = false;

        // Начальная позиция
        int startPositionX = surfaceView.getWidth() / 2;
        int startPositionY = playableHeight > 0 ? playableHeight / 2 : surfaceView.getHeight() / 2;

        for(int i = 0; i < DEFAULT_TALE_POINTS; i++) {
            snakePointsList.add(new SnakePoints(startPositionX - (i * POINT_SIZE * 2), startPositionY));
        }

        addPoint();
        isGameRunning = true;
        startGame();
    }

    private void startGame() {
        gameThread = new Thread(() -> {
            while(isGameRunning && !Thread.interrupted()) {
                update();
                render();

                try {
                    Thread.sleep(SNAKE_MOVING_SPEED);
                } catch (InterruptedException e) {
                    break;
                }
            }
        });
        gameThread.start();
    }

    private void stopGame() {
        isGameRunning = false;
        if(gameThread != null) {
            gameThread.interrupt();
            try {
                gameThread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            gameThread = null;
        }
    }

    private void update() {
        if (!isGameRunning) return;

        // Движение змейки
        int headX = snakePointsList.get(0).getPositionX();
        int headY = snakePointsList.get(0).getPositionY();
        int prevX = headX;
        int prevY = headY;

        switch(movingPosition) {
            case "right": headX += POINT_SIZE * 2; break;
            case "left": headX -= POINT_SIZE * 2; break;
            case "top": headY -= POINT_SIZE * 2; break;
            case "bottom": headY += POINT_SIZE * 2; break;
        }

        // Проверка съедения еды
        if(Math.abs(headX - positionX) < POINT_SIZE && Math.abs(headY - positionY) < POINT_SIZE) {
            growSnake();
            addPoint();
        }

        // Обновление позиций тела
        for(int i = 1; i < snakePointsList.size(); i++) {
            int tempX = snakePointsList.get(i).getPositionX();
            int tempY = snakePointsList.get(i).getPositionY();
            snakePointsList.get(i).setPositionX(prevX);
            snakePointsList.get(i).setPositionY(prevY);
            prevX = tempX;
            prevY = tempY;
        }

        snakePointsList.get(0).setPositionX(headX);
        snakePointsList.get(0).setPositionY(headY);

        // Проверка конца игры
        if(checkGameOver(headX, headY)) {
            gameOver = true;
            stopGame();
            runOnUiThread(this::showGameOverDialog);
        }
    }

    private void render() {
        if(surfaceHolder == null || !surfaceHolder.getSurface().isValid()) return;

        Canvas canvas = surfaceHolder.lockCanvas();
        if(canvas == null) return;

        try {
            synchronized(surfaceHolder) {
                // Фон
                canvas.drawColor(backgroundColor, PorterDuff.Mode.CLEAR);

                // Сетка
                int gridSize = POINT_SIZE * 2;
                int width = surfaceView.getWidth();
                int height = playableHeight > 0 ? playableHeight : surfaceView.getHeight();
                for (int x = 0; x < width; x += gridSize) {
                    canvas.drawLine(x, 0, x, height, gridPaint);
                }
                for (int y = 0; y < height; y += gridSize) {
                    canvas.drawLine(0, y, width, y, gridPaint);
                }

                // Еда
                canvas.drawCircle(positionX, positionY, POINT_SIZE, foodPaint);

                // Тень еды
                Paint shadowPaint = new Paint();
                shadowPaint.setColor(ContextCompat.getColor(this, R.color.food_shadow));
                shadowPaint.setAlpha(100);
                canvas.drawCircle(positionX + 4, positionY + 4, POINT_SIZE, shadowPaint);

                // Змейка
                for(int i = 0; i < snakePointsList.size(); i++) {
                    SnakePoints point = snakePointsList.get(i);

                    // Голова
                    if(i == 0) {
                        Paint headPaint = new Paint(snakePaint);
                        headPaint.setColor(ContextCompat.getColor(this, R.color.snake_head));
                        canvas.drawCircle(point.getPositionX(), point.getPositionY(), POINT_SIZE, headPaint);
                    }
                    // Тело
                    else {
                        canvas.drawCircle(point.getPositionX(), point.getPositionY(), POINT_SIZE, snakePaint);
                    }

                    // Тень сегментов
                    Paint segmentShadow = new Paint();
                    segmentShadow.setColor(ContextCompat.getColor(this, R.color.snake_shadow));
                    segmentShadow.setAlpha(100);
                    canvas.drawCircle(point.getPositionX() + 3, point.getPositionY() + 3, POINT_SIZE - 2, segmentShadow);
                }

                // Счет
                canvas.drawText("Score: " + score, 50, 80, scorePaint);
            }
        } finally {
            surfaceHolder.unlockCanvasAndPost(canvas);
        }
    }

    private void addPoint() {
        if (surfaceView.getWidth() == 0 || surfaceView.getHeight() == 0) return;

        int actualPlayableHeight = playableHeight > 0 ? playableHeight :
                surfaceView.getHeight() - controlsLayout.getHeight();

        if (actualPlayableHeight <= 0) return;

        int surfaceWidth = surfaceView.getWidth() - (POINT_SIZE * 4);
        int surfaceHeight = actualPlayableHeight - (POINT_SIZE * 4);

        if (surfaceWidth <= 0 || surfaceHeight <= 0) return;

        int randomX = new Random().nextInt(surfaceWidth / (POINT_SIZE * 2));
        int randomY = new Random().nextInt(surfaceHeight / (POINT_SIZE * 2));

        positionX = (POINT_SIZE * 2 * randomX) + POINT_SIZE * 2;
        positionY = (POINT_SIZE * 2 * randomY) + POINT_SIZE * 2;

        // Корректировка позиции
        positionX = Math.max(POINT_SIZE * 2, Math.min(positionX, surfaceView.getWidth() - POINT_SIZE * 2));
        positionY = Math.max(POINT_SIZE * 2, Math.min(positionY, actualPlayableHeight - POINT_SIZE * 2));
    }

    private void growSnake() {
        snakePointsList.add(new SnakePoints(0, 0));
        score++;
    }

    private boolean checkGameOver(int headX, int headY) {
        int actualPlayableHeight = playableHeight > 0 ? playableHeight :
                surfaceView.getHeight() - controlsLayout.getHeight();

        if (actualPlayableHeight <= 0) {
            actualPlayableHeight = surfaceView.getHeight();
        }

        // Столкновение со стенами
        if(headX - POINT_SIZE <= 0 ||
                headY - POINT_SIZE <= 0 ||
                headX + POINT_SIZE >= surfaceView.getWidth() ||
                headY + POINT_SIZE >= actualPlayableHeight) {
            return true;
        }

        // Столкновение с собой
        for(int i = 1; i < snakePointsList.size(); i++) {
            if(headX == snakePointsList.get(i).getPositionX() &&
                    headY == snakePointsList.get(i).getPositionY()) {
                return true;
            }
        }

        return false;
    }

    private void showGameOverDialog() {
        AlertDialog dialog = new AlertDialog.Builder(this, R.style.CustomDialogTheme)
                .setMessage("Your score: " + score)
                .setTitle("Game Over")
                .setCancelable(false)
                .setPositiveButton("Play Again", (d, which) -> init())
                .setNegativeButton("Exit", (d, which) -> finish())
                .create();

        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setTextColor(ContextCompat.getColor(this, R.color.snake_green));
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE)
                .setTextColor(ContextCompat.getColor(this, R.color.food_red));
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopGame();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(surfaceHolder != null && surfaceHolder.getSurface().isValid() && !gameOver) {
            startGame();
        }
    }

    static class SnakePoints {
        private int positionX;
        private int positionY;

        SnakePoints(int positionX, int positionY) {
            this.positionX = positionX;
            this.positionY = positionY;
        }

        int getPositionX() {
            return positionX;
        }

        int getPositionY() {
            return positionY;
        }

        void setPositionX(int positionX) {
            this.positionX = positionX;
        }

        void setPositionY(int positionY) {
            this.positionY = positionY;
        }
    }
}